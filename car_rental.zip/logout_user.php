<?php
require('connection.inc.php');
unset($_SESSION['usercvgfth']);
header('location:index.php');
?>